package org.gnudot.orgfb2;

/**
 * Created by IntelliJ IDEA.
 * User: andrep
 * Date: Nov 7, 2009
 * Time: 2:42:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class PossibleNPE {

    public Object getNull() {
        return null;
    }

    
    public void doGetNPE() {
        boolean b = getNull().equals("1");
    }
}
