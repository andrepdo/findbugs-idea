package org.gnudot.orgfb2;

import javax.swing.*;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: andrep
 * Date: Nov 1, 2008
 * Time: 7:54:41 PM
 * To change this template use File | Settings | File Templates.
 */
public class MyClass3 {
    
    private Map map1;

    
    public void testMe() {

        map1.put("key", "value");
        System.exit(1);
    }


    public void testMeAgain() {

        System.exit(1);
       
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //To change body of implemented methods use File | Settings | File Templates.
                System.exit(1);
            }
        });
    }
}

class MyClass3_1 {


    private Map map;


    public MyClass3_1() {

    }

    public void testMe3() {


        map.put("1", "value");

        System.err.println("test");
        System.exit(1);

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {

                //To change body of implemented methods use File | Settings | File Templates.
                System.exit(1);
            }
        });

    }
}