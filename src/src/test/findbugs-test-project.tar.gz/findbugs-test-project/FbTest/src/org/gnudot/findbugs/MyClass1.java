package org.gnudot.findbugs;

import javax.swing.*;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: andrep
 * Date: Oct 26, 2008
 * Time: 7:05:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class MyClass1 {
    

    private Map map3;
    
    public void tstMe() {
        

        map3.put("3", "value3");

        
        synchronized (this) {

        }

        System.exit(1);

        
        System.exit(1);

    }
}


class OuterClass06 {

    private Map map;
    private Map map1;

    OuterClass06() {
        synchronized (this) {
                     }
        map.get(0);
        System.exit(1);

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //To change body of implemented methods use File | Settings | File Templates.
                System.exit(1);
            }
        });

    }
}
