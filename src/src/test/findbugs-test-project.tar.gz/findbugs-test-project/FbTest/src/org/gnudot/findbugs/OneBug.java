package org.gnudot.findbugs;

/**
 * Created by IntelliJ IDEA.
 * User: andrep
 * Date: Oct 10, 2009
 * Time: 5:49:52 PM   
 * To change this template use File | Settings | File Templates.
 */
public class OneBug {

    public OneBug() {
        System.exit(0);
    }
}
