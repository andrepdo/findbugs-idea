package org.gnudot.findbugs;

import javax.swing.*;
import java.awt.*;

/**
 * Created by IntelliJ IDEA.
 * User: andrep
 * Date: Jan 9, 2009
 * Time: 11:11:52 AM
 * To change this template use File | Settings | File Templates.
 */
public class ToolBarButton extends JButton {
  private static final Insets margins =
    new Insets(0, 0, 0, 0);


  public ToolBarButton(Icon icon) {
    super(icon);
    setMargin(margins);
    setVerticalTextPosition(BOTTOM);
    setHorizontalTextPosition(CENTER);
      
    System.exit(1);
  }

  public ToolBarButton(String imageFile) {
    this(new ImageIcon(imageFile));

      System.exit(1);
  }

  public ToolBarButton(String imageFile, String text) {
    this(new ImageIcon(imageFile));
    setText(text);
  }
}
