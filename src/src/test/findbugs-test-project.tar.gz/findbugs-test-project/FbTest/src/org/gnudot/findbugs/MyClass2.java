package org.gnudot.findbugs;

import javax.swing.*;
import java.util.Map;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: andrep
 * Date: Oct 26, 2008
 * Time: 7:05:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class MyClass2 {


    private Map map;

    class NonStaticInnerClass {
        NonStaticInnerClass() {
            System.exit(1);
        }
    }

    public MyClass2() {

        final int index = "abcd".indexOf('b');
        System.exit(1);
        

    }

    public void testMe() {


        synchronized (this) {

        }

        map.put("1", "value");
        
        final int index = "abcd".indexOf('b');

        System.err.println("test");
        System.exit(1);

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //To change body of implemented methods use File | Settings | File Templates.
                System.exit(1);
            }
        });

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //To change body of implemented methods use File | Settings | File Templates.
                System.exit(1);
            }
        });
    }

    class InnerClass01 {

        InnerClass01() {
            System.exit(1);

            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    //To change body of implemented methods use File | Settings | File Templates.
                    System.exit(1);
                }
            });
        }

        class InnerInnerClass01 {
            

            InnerInnerClass01() {
                System.exit(1);
                

                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        //To change body of implemented methods use File | Settings | File Templates.
                        System.exit(1);
                        

                        SwingUtilities.invokeLater(new Runnable() {
                            public void run() {
                                // To change body of implemented methods use File | Settings | File Templates.
                                System.exit(1);
                            }
                        });

                        class AnonymousInner1 {
                            AnonymousInner1() {
                                System.exit(1);
                            }
                        }

                    }
                }
                );
            }
        }
    }

}

class OuterClass02 {

    OuterClass02() {
        System.exit(1);

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //To change body of implemented methods use File | Settings | File Templates. //To change body of implemented methods use File | Settings | File Templates.
            }
        });
    }
}


class MyClass5 {

    private Map map;

    public MyClass5() {
        System.exit(1);
    }

    public void testMe() {


        map.put("1",

                "value");
        

        System.err.println("test");
        System.exit(1);

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //To change body of implemented methods use File | Settings | File Templates.
                System.exit(1);
            }
        });

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //To change body of implemented methods use File | Settings | File Templates.
                System.exit(1);
            }
        });
    }

    class InnerClass01 {

        InnerClass01() {
            System.exit(1);

            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    System.exit(1);
                }
            });
        }

        class InnerInnerClass01 {

            InnerInnerClass01() {
                System.exit(1);

                SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        //To change body of implemented methods use File | Settings | File Templates.
                        System.exit(1);

                        SwingUtilities.invokeLater(new Runnable() {
                            public void run() {
                                // To change body of implemented methods use File | Settings | File Templates.
                                System.exit(1);
                            }
                        });

                        class AnonymousInner2 {
                            AnonymousInner2() {
                                System.exit(1);
                            }
                        }

                    }
                }
                );
            }
        }
    }

}

class OuterClass05 {

    OuterClass05() {
        System.exit(1);

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                //To change body of implemented methods use File | Settings | File Templates.
            }
        });
    }
}


class OuterNOBug {
    OuterNOBug() {
        System.exit(1);
    }
}