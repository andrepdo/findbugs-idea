public class Test {
    public static void sayHello() {
        System.out.println("Hello");
    }
    public static void main(String[] args) {
        sayHello();
    }
}