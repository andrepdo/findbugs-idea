
  object Test1 {

    def main(args: Array[String]) {
      println("Hello, world!")
      var a = 0
      // for loop execution with a range
      var x = ""
      for( a <- 1 to 10){
        println( "Value of a: " + a )
        x += "2" + a
      }


      var sb1 = new StringBuilder("1234")
      var sb2 = new StringBuilder("1234")
      var string1 = sb1.toString()
      var string2 = sb2.toString()



      System.out.println("   - " + (string1 == string2))

    }


}




