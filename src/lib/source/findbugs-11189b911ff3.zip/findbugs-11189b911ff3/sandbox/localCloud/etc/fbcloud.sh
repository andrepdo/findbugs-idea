#!/bin/sh
java -jar localCloud.jar