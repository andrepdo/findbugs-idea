public class MakeFieldStaticResolutionExample {
    final String GREETING = "Hello World";
}
