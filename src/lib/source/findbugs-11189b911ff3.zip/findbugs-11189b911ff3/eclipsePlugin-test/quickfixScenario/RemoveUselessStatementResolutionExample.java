public class RemoveUselessStatementResolutionExample {

    public void doSomething() {
        synchronized (this) {
        }
    }
}
