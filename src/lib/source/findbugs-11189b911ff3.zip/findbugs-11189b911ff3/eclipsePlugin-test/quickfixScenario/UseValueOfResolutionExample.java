public class UseValueOfResolutionExample {
    public Boolean getBoolean(boolean value) {
        return new Boolean(value);
    }

    public Integer getInteger(int value) {
        return new Integer(value);
    }
}
