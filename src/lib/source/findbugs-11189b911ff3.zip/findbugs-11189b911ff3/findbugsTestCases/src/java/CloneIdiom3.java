public class CloneIdiom3 implements Cloneable {
    @Override
    public Object clone() {
        return new CloneIdiom3();
    }
}
