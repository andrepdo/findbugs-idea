public class AssignedOnlyInCtor {
    private int value;

    public AssignedOnlyInCtor(int value) {
        this.value = value;
    }

    public int getValue() {
        return value;
    }

}
