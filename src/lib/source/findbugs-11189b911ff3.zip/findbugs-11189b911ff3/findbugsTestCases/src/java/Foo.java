public class Foo {
    static Class other;
    static {
        other = Bar.other;
    }
}
