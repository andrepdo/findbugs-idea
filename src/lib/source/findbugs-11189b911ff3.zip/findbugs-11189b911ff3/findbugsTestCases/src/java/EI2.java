
public class EI2 {

    EI2[] myArray;

    /**
     * @param args
     */
    public void setStuff(EI2[] myArray) {
        if (myArray.length > 0)
            this.myArray = myArray;
    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

}
