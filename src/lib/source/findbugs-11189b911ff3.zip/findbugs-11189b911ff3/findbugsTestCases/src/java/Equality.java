public class Equality {

    /**
     * @param args
     */

    public boolean equals(Equality e) {
        return true;
    }

    @Override
    public boolean equals(Object o) {
        return false;
    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

}
