public interface I1 {
    public void i1();
}
