public class Bar {
    static Class other;
    static {
        other = Foo.other;
    }
}
