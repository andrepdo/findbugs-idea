package bugIdeas;

public class Ideas_2009_01_29 {

    public static void printIntValue(int x) {
        System.out.printf(" int value = %d " + x);
    }

}
