import junit.framework.Test;

public class MyTestCase2 extends MyTestCase {
    @Override
    public void setUp() {
    }

    @Override
    public void tearDown() {
    }

    @Override
    public Test suite() {
        return null;
    }
}
