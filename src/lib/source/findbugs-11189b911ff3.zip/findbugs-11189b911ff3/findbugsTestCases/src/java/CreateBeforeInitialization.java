class CreateBeforeInitialization {

    static CreateBeforeInitialization foo = new CreateBeforeInitialization();

    static int x = 42;
}
